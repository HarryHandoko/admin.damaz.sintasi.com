import{O as o}from"./B7LgmnEZ.js";const i=o("/favicon.ico");export{i as _};
