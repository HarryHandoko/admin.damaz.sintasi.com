import{O as o}from"./DbG9Cujt.js";const i=o("/favicon.ico");export{i as _};
