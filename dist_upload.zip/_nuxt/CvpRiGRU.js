import{_ as e,c,o as n}from"./DbG9Cujt.js";const o={};function r(t,s){return n(),c("div")}const a=e(o,[["render",r]]);export{a as default};
