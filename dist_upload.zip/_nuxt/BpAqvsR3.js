import"./B7LgmnEZ.js";const a=""+new URL("auth-v1-bottom-shape.crxWNCWd.svg",import.meta.url).href,e=""+new URL("auth-v1-top-shape.eAwqa87i.svg",import.meta.url).href;export{e as a,a as b};
